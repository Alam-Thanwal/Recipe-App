var inputbox=document.querySelector(".inputText");
var button_61=document.querySelector(".button-61");
// recipe_details_content
var text=document.querySelector(".h2");

var recipe_container=document.querySelector(".recipe_container");
var recipeDetailsContent=document.querySelector(".recipe_details_content");
var recipeClose_btn=document.querySelector(".recipe_close_btn");

async function getNow(){
    const data =await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=`)
    const response=await data.json()


    response.meals.map(index=>{
        // console.log(index);
        const recipeDiv=document.createElement('Div');
        recipeDiv.classList.add('recipe')
        // recipeDiv.style.border="1px solid red"
        recipeDiv.innerHTML=`
        <img src="${index.strMealThumb}">
        <h3>${index.strMeal}</h3>
        <p><span>${index.strArea}</span> Dish</p>
        <p>Belongs to <span>${index.strCategory}</span> Category</p>
        `
        const button=document.createElement('button')
        button.textContent="View recipe"
        recipeDiv.appendChild(button)
        recipe_container.appendChild(recipeDiv)


        button.addEventListener('click',()=>{
            openRecipePopup(index)
        })
        
    })

 
    
    }
    getNow()
const fetchRecipe= async(query)=>{
    // www.themealdb.com/api/json/v1/1/search.php?s=Arrabiata
    // text.innerHTML="<h2>Fecthing Recipes...</h2>"
    try {
        
   
    const data =await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`)
    const response=await data.json()



    recipe_container.innerHTML="";

    response.meals.map(index=>{
        // console.log(index);
        const recipeDiv=document.createElement('Div');
        recipeDiv.classList.add('recipe')
        // recipeDiv.style.border="1px solid red"
        recipeDiv.innerHTML=`
        <img src="${index.strMealThumb}">
        <h3>${index.strMeal}</h3>
        <p><span>${index.strArea}</span> Dish</p>
        <p>Belongs to <span>${index.strCategory}</span> Category</p>
        `
        const button=document.createElement('button')
        button.textContent="View recipe"
        recipeDiv.appendChild(button)
        recipe_container.appendChild(recipeDiv)


        button.addEventListener('click',()=>{
            openRecipePopup(index)
        })
        
    })
} catch (error) {
    // recipeDiv.innerHTML=""
     

    recipe_container.innerHTML=`<h2 class="h2" style="color: red;">Errro in Fecthing Recipes...</h2>
 <img src="Assets/error2.avif" class="error" alt="error2">`
    // recipe_container.innerHTML=``

        
}
}

const fetchIngredents=(index)=>{
    // console.log(index);
    let ingredentList="";
    for(var i=1;i<=20;i++){
        const ingredent=index[`strIngredient${i}`];
        if(ingredent){
            const measure=index[`strMeasure${i}`]
            ingredentList+=`<li>${measure} - ${ingredent}</li>`
        }
        else{
            break;
        }
    }
    return ingredentList

}

const openRecipePopup=(index)=>{
    recipeDetailsContent.innerHTML=`
    <h2>${index.strMeal}</h2>
    <h3>Ingredents:</h3>
    <ul>${fetchIngredents(index)}</ul>
    <div>
    <h3>Instruction: </h3>
    <p>${index.strInstructions}</p></div>`
    
    

    recipeDetailsContent.parentElement.style.display="block"
}

recipeClose_btn.addEventListener('click', ()=>{
    recipeDetailsContent.parentElement.style.display="none";

})
button_61.addEventListener('click',(e)=>{
    e.preventDefault()
    const inputfield=inputbox.value.trim()
    if(!inputfield){
        recipe_container.innerHTML=`<h2 style="color: red;">Type the meal in the search box.</h2>`
        return
    }
    fetchRecipe(inputfield)
})